# springboot-shiro
使用SpringBoot与shiro实现基于数据库的细粒度动态权限管理系统实例。 
详情请看http://blog.csdn.net/poorcoder_/article/details/71374002
