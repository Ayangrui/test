package com.study.mapper;

import com.study.model.RoleResources;
import com.study.util.MyMapper;

public interface RoleResourcesMapper extends MyMapper<RoleResources> {
}