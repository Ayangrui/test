package com.study.service;

import com.study.model.RoleResources;

/**
 * Created by yangqj on 2017/4/26.
 */
public interface RoleResourcesService extends IService<RoleResources>  {
    public void addRoleResources(RoleResources roleResources);
}
